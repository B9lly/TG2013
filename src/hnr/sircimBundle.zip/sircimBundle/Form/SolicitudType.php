<?php

namespace hnr\sircimBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class SolicitudType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('soTipo')
            ->add('soFecha')
            ->add('soRegion')
            ->add('soPosicion')
            ->add('idMntExpediente')
            ->add('idMntAtenAreaModEstab')
            ->add('idEstudioArea')
        ;
    }

    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'hnr\sircimBundle\Entity\Solicitud'
        ));
    }

    public function getName()
    {
        return 'hnr_sircimbundle_solicitudtype';
    }
}
