<?php

namespace hnr\sircimBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class hnrsircimBundle extends Bundle
{
}
